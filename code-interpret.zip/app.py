from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import subprocess
from langchain_experimental.utilities import PythonREPL
from celery import Celery
import os

app = FastAPI()
python_repl = PythonREPL()
celery_app = Celery('tasks', broker='redis://redis:6379/0', backend='redis://redis:6379/0')

class CodeRequest(BaseModel):
    code: str
    packages: list[str] = []

@celery_app.task
def install_packages(packages):
    try:
        result = subprocess.run(
            ["pip", "install"] + packages,
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            return {"error": result.stderr}
        return {"output": result.stdout}
    except Exception as e:
        return {"error": str(e)}

@celery_app.task
def uninstall_packages(packages):
    try:
        result = subprocess.run(
            ["pip", "uninstall", "-y"] + packages,
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            return {"error": result.stderr}
        return {"output": result.stdout}
    except Exception as e:
        return {"error": str(e)}

@celery_app.task
def restart_worker():
    subprocess.run(["supervisorctl", "restart", "celery_worker"])

@celery_app.task(bind=True)
def execute_code_with_packages(self, code, packages):
    try:
        if packages:
            # Install packages
            install_result = install_packages(packages)
            if 'error' in install_result:
                return {"install_error": install_result["error"]}

        # Execute code
        output = python_repl.run(code)
        return {"output": output}
    except Exception as e:
        return {"error": str(e)}
    finally:
        # Restart worker
        restart_worker.delay()

@app.post("/execute_with_packages")
def execute_code_with_packages_endpoint(request: CodeRequest):
    task = execute_code_with_packages.delay(request.code, request.packages)
    return {"task_id": task.id}

@app.get("/status/{task_id}")
def get_task_status(task_id: str):
    task = celery_app.AsyncResult(task_id)
    if task.state == 'PENDING':
        return {"status": "Pending"}
    elif task.state == 'SUCCESS':
        return {"status": "Success", "result": task.result}
    elif task.state == 'FAILURE':
        return {"status": "Failure", "result": str(task.info)}
    else:
        return {"status": str(task.state)}

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=8000)
