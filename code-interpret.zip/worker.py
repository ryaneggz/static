# worker.py
from app import celery_app

celery_app.conf.update(
    broker_url='redis://redis:6379/0',
    result_backend='redis://redis:6379/0',
)

if __name__ == '__main__':
    celery_app.start()