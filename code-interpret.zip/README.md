# Example Commands

## Install and Run

```bash
docker-compose up --build
```

## Run Examples

### Verify package is not installed

Can watch logs for simple checks.

```bash
curl -X POST "http://localhost:8000/execute_with_packages" \
     -H "Content-Type: application/json" \
     -d '{
           "code": "import pandas; print(pandas.__version__)"
         }'
```

### Get task output from API

```bash
curl -X GET "http://localhost:8000/status/$TASK_ID"
```

### Install package and perform execution

This is supposed to uninstall pacakges after execution which "seems" to work
but proves otherwise by running the commands below this.

```bash
curl -X POST "http://localhost:8000/execute_with_packages" \
     -H "Content-Type: application/json" \
     -d '{
           "code": "import pandas as pd\n\ndf = pd.DataFrame([1, 2, 3], columns=[\"Numbers\"])\n\nprint(df)",
           "packages": ["pandas"]
         }'
```

### Can execute again this time without passing pages (Should not happen)

Can see version from previous run.

```bash
curl -X POST "http://localhost:8000/execute_with_packages" \
     -H "Content-Type: application/json" \
     -d '{
           "code": "import pandas; print(pandas.__version__)"
         }'
```

Can see code can execute without the pacakges being passed.

```bash
curl -X POST "http://localhost:8000/execute_with_packages" \
     -H "Content-Type: application/json" \
     -d '{
           "code": "import pandas as pd\n\ndf = pd.DataFrame([1, 2, 3], columns=[\"Numbers\"])\n\nprint(df)"
         }'
```